package com.example.MovieManagingService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovieManagingControllerApplicationTests {

	@Test
	void contextLoads() {
	}

}
