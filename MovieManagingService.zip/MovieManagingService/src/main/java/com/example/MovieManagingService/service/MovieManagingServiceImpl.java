package com.example.MovieManagingService.service;
import com.example.MovieManagingService.exception.NotFoundException;
import com.example.MovieManagingService.model.History;
import com.example.MovieManagingService.model.Movie;
import com.example.MovieManagingService.repo.MovieManagingRepo;
import com.example.MovieManagingService.repo.TicketLogRepo;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import javax.transaction.Transactional;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import static com.example.MovieManagingService.constant.Constants.TICKETSERVICE_URL_IP;
import static org.springframework.http.HttpStatus.*;


@Service
@Transactional
public class MovieManagingServiceImpl implements MovieManagingService{

    @Autowired
    private MovieManagingRepo movieManagingRepo;

    @Autowired
    private TicketLogRepo ticketLogRepo;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private RestTemplate restTemplate;

    private String kafkaMessage;

    private List<Movie> history;

    private List<Movie> movieList;

    @Override
    public ResponseEntity postMovie(Movie movie){
        movieManagingRepo.save(movie);
        return new ResponseEntity(HttpStatus.OK);
    }

    @Override
    public ResponseEntity getAllMovie() {
        movieList = movieManagingRepo.findAll();
        return !movieList.isEmpty()
                ? new ResponseEntity<List<Movie>>(movieList,OK)
                : new ResponseEntity<List<Movie>>(NOT_FOUND);

    }

    @Override
    public  Movie getMovieById(@PathVariable int id) throws  NotFoundException {
       return movieManagingRepo.findById(id).orElseThrow(NotFoundException::new);
    }

    @Override
    public ResponseEntity getAllMovieSortedByIdDesc() {
        movieList = movieManagingRepo.findAll();
        movieList = (List<Movie>) movieList.stream().sorted(Collections.reverseOrder()).collect(Collectors.toList());//(movieList.toArray());
        return !movieList.isEmpty()
                ? new ResponseEntity<List<Movie>>(movieList,HttpStatus.OK)
                : new ResponseEntity<List<Movie>>(NOT_FOUND);
    }

    @Override
    public ResponseEntity getAllMovieSortedByName() {
        movieList = movieManagingRepo.findAllByOrderByName();
        return !movieList.isEmpty()
                ? new ResponseEntity<List<Movie>>(movieList,OK)
                : new ResponseEntity<List<Movie>>(NOT_FOUND);
    }

    @Override
    public ResponseEntity getAllMovieSortedByTicketSold() {
        movieList = movieManagingRepo.findAllByOrderByTicketsSold();
        return !movieList.isEmpty()
                ? new ResponseEntity<List<Movie>>(movieList,OK)
                : new ResponseEntity<List<Movie>>(NOT_FOUND);
    }

    @Override
    public void deleteMovieByName(String name) {
        movieManagingRepo.deleteByName(name);
    }


    @Override
    public List getHistroy() {
        List<History> historyList = ticketLogRepo.findAll();
        return historyList;
    }

//    @Override
    public ResponseEntity getTotalNoTickets(int id) {
        String URI = UriComponentsBuilder.fromHttpUrl(TICKETSERVICE_URL_IP).encode().toUriString();
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        Integer tickets = restTemplate.exchange(URI,HttpMethod.GET,null, Integer.class).getBody();
        return new ResponseEntity<>(tickets,HttpStatus.OK);

    }

    @Override
    public ResponseEntity editMovieDetails(Movie movie){
        try{
            Movie movieGet = movieUpdateSetter(movie);
            movieManagingRepo.save(movie);
            return new ResponseEntity(HttpStatus.OK);
        }catch (Exception e){
            return new ResponseEntity<>(e.getMessage(),HttpStatus.NOT_FOUND);
        }
    }

    public Movie movieUpdateSetter(Movie movie){
        Movie movieModel = new Movie();
        movieModel.setDescription(movie.getDescription());
        movieModel.setImageUrl(movie.getImageUrl());
        movieModel.setName(movie.getName());
        movieModel.setTicketPrice(movie.getTicketPrice());
        movieModel.setTimeSlot(movie.getTimeSlot());
        movieModel.setVideoUrl(movie.getVideoUrl());
        movieModel.setTotal_no_tickets(movie.getTotal_no_tickets());
        return movieModel;
    }
}
