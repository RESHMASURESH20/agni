package com.example.MovieManagingService.consumer;

import com.example.MovieManagingService.model.History;
import com.example.MovieManagingService.model.Movie;
import com.example.MovieManagingService.repo.MovieManagingRepo;
import com.example.MovieManagingService.repo.TicketLogRepo;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import java.util.logging.Logger;

@Component
public class Consumer {

    @Autowired
    MovieManagingRepo movieManagingRepo;

    @Autowired
    TicketLogRepo ticketLogRepo;

    @Autowired
    ObjectMapper objectMapper;
    Movie movie;
    @KafkaListener(containerFactory = "kafkaListenerContainerFactory", topics = "ticket", groupId = "group_id")
    public void consumeMessage(String message){
        Logger logger = Logger.getLogger(message);
        try {
            History history = objectMapper.readValue(message,History.class);
            ticketLogRepo.save(history);
            logger.info("successfully inserted.");
        } catch (JsonProcessingException e) {
            System.out.println(e.getMessage());
        }
    }
}
