package com.example.MovieManagingService.service;

import com.example.MovieManagingService.exception.NotFoundException;
import com.example.MovieManagingService.model.Movie;
import org.springframework.http.ResponseEntity;

import java.util.List;

public interface MovieManagingService {

    ResponseEntity postMovie(Movie movie);
    ResponseEntity getAllMovie();
    Movie getMovieById(int id) throws NotFoundException;
    ResponseEntity<List<Movie>> getAllMovieSortedByIdDesc();
    ResponseEntity getAllMovieSortedByName();
    ResponseEntity getAllMovieSortedByTicketSold();
    ResponseEntity editMovieDetails(Movie movie) throws Exception;
    List getHistroy();
    ResponseEntity getTotalNoTickets(int id);
    void deleteMovieByName(String name);
}
