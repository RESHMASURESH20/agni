package com.example.MovieManagingService.repo;

import com.example.MovieManagingService.model.History;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TicketLogRepo extends JpaRepository<History,Integer> {
}
