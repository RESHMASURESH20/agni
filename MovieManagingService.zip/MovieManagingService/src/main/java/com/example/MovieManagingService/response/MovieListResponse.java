package com.example.MovieManagingService.response;

import com.example.MovieManagingService.model.Movie;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class MovieListResponse extends Respone{
    private int status_code;
    private int message;
    private List<Movie> data;
}
