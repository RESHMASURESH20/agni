package com.example.MovieManagingService.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "history")
public class History {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer historyId;
    private int ticketid;
    private String customername;
    private int movieid;
    private String moviename;
    private int netprice;
    private int noofticket;
    private String mobilenumber;
}
