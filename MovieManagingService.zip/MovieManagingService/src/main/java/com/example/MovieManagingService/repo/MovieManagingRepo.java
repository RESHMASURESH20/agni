package com.example.MovieManagingService.repo;


import com.example.MovieManagingService.model.Movie;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MovieManagingRepo extends JpaRepository<Movie,Integer> {
    List<Movie> findAllByOrderByName();
    List<Movie> findAllByOrderByTicketsSold();
    void deleteByName(String name);
}
