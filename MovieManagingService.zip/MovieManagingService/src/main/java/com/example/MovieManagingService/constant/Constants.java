package com.example.MovieManagingService.constant;

import org.springframework.stereotype.Component;

@Component
public interface Constants {
    String ADMIN_BASE_URL = "/admin";
    String  POST_MOVIE_URL = "/post/movie";
    String  GET_MOVIE_BY_ID_URL = "get/movie/{id}";
    String  GET_MOVIE_URL = "get/movie";
    String  GET_MOVIE_SORT_BY_NAME_URL = "get/movie/sortByName";

    String GET_HISTORY = "/history";

    String CROSS_ORGIN = "http://localhost:8080";


    String MOVIE_NOT_FOUND = "Movie not GET_MOVIE_SORT_BY_ID_DESC_URLFound";
    String MOVIE_NOT_FOUND_ID = "Movie not Found ID : ";
    String MOVIE_NOT_FOUND_NAME = "Movie not Found ID : ";
    String NO_RECORDS = "No Records in Table!!!";

    String DELETE_MOVIE_URL = "/delete/movie/{name}";

    String TICKETSERVICE_URL_IP = "http://10.30.1.159:8089/ticketBooking/ticketNoToMovieService/{id}";

}
