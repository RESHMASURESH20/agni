package com.example.MovieManagingService.controller;

import com.example.MovieManagingService.exception.NotFoundException;
import com.example.MovieManagingService.model.Movie;
import com.example.MovieManagingService.service.MovieManagingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static com.example.MovieManagingService.constant.Constants.*;

@RestController
@RequestMapping(ADMIN_BASE_URL)
public class MovieManagingController {

    @Autowired
    private MovieManagingService movieManagingService;

    @Autowired
    private KafkaTemplate kafkaTemplate;

    @PostMapping(POST_MOVIE_URL)
    @CrossOrigin(origins=CROSS_ORGIN)
    public void postMovie(@RequestBody Movie movie){
        movieManagingService.postMovie(movie);
    }

    @GetMapping(GET_MOVIE_URL)
    @CrossOrigin(origins=CROSS_ORGIN)
    public ResponseEntity getAllMovie(){
        return movieManagingService.getAllMovie();
    }


    @GetMapping(GET_MOVIE_BY_ID_URL)
    @CrossOrigin(origins=CROSS_ORGIN)
    public ResponseEntity getMovieById(@PathVariable("id") int id){
        try{
            return new ResponseEntity<>(movieManagingService.getMovieById(id),HttpStatus.OK);
        }catch (NotFoundException e){
            return new ResponseEntity<>(e.getMessage(id),HttpStatus.NOT_FOUND);
        }
    }


    @GetMapping()
    @CrossOrigin(origins=CROSS_ORGIN)
    public ResponseEntity getAllMovieSortedByMovieIdDesc(){
        return movieManagingService.getAllMovieSortedByIdDesc();
    }


    @GetMapping(GET_MOVIE_SORT_BY_NAME_URL)
    @CrossOrigin(origins=CROSS_ORGIN)
    public ResponseEntity getAllMovieSortedByName(){
        return movieManagingService.getAllMovieSortedByName();
    }


    @GetMapping(GET_HISTORY)
    public ResponseEntity getHistroy(){
        List movieList = movieManagingService.getHistroy();
        return !movieList.isEmpty()
                ? new ResponseEntity<>(movieList,HttpStatus.OK)
                : new ResponseEntity<>(NO_RECORDS,HttpStatus.NOT_FOUND);
    }

    @DeleteMapping(DELETE_MOVIE_URL)
    @CrossOrigin(origins=CROSS_ORGIN)
    public ResponseEntity deleteMovie(@PathVariable String name){
        try{
            movieManagingService.deleteMovieByName(name);
            return new ResponseEntity<>(HttpStatus.OK);
        }catch (Exception e){
            System.out.println(e.getMessage());
            return new ResponseEntity<>(NO_RECORDS,HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping("tickets/sold")
    public ResponseEntity getMovieTicketsBooked(@PathVariable int id){
        return movieManagingService.getTotalNoTickets(id);
    }

//    @PutMapping("")
//    @CrossOrigin(origins = CROSS_ORGIN)
//    public ResponseEntity editMovieDetail(@RequestBody Movie movie){
//        try {
//            return movieManagingService.editMovieDetails(movie);
//        } catch (Exception e) {
//            return new ResponseEntity<>(e.getMessage(),HttpStatus.BAD_REQUEST);
//        }
//    }

}
