package com.example.MovieManagingService.model;

import com.sun.istack.NotNull;
import lombok.*;

import javax.persistence.*;



@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Entity
@Table(name = "Movie")
public class Movie {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer movieId;
    @NonNull
    @Column(unique = true)
    private String name;
    @NonNull
    private String imageUrl;
    @NonNull
    private String description;
    @NonNull
    private Integer total_no_tickets;
    @NonNull
    private Integer ticketPrice;
    @NonNull
    private String timeSlot;
    @NonNull
    private String videoUrl;

    @Column(columnDefinition = "integer default 0")
    private Integer ticketsSold=0;
}
