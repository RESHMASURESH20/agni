package com.example.MovieManagingService.response;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Respone {
    protected int status_code;
    protected String status;
    protected int message;
}
