package com.example.MovieManagingService.exception;

import com.example.MovieManagingService.constant.Constants;


public class NotFoundException extends Exception{

    public String getMessage() {
        return Constants.MOVIE_NOT_FOUND;
    }

    public String getMessage(int Id) {
        return Constants.MOVIE_NOT_FOUND_ID + Id;
    }

    public String getMessage(String name) {
        return Constants.MOVIE_NOT_FOUND_NAME + name;
    }
}
