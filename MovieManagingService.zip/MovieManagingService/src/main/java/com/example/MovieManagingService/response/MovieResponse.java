package com.example.MovieManagingService.response;
import com.example.MovieManagingService.model.Movie;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MovieResponse extends Respone {
    private int status_code;
    private int message;
    private Movie data;
}
