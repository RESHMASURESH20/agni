package com.example.MovieManagingService.exception;

public class SameFieldException extends Exception {
    @Override
    public String getMessage() {
        return "Record is already exist. Can't insert duplicate.";
    }
}
