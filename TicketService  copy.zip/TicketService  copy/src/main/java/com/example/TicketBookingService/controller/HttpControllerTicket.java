package com.example.TicketBookingService.controller;

import com.example.TicketBookingService.constant.Constant;
import com.example.TicketBookingService.customException.CustomerDataNotFoundException;
import com.example.TicketBookingService.model.Customer;
import com.example.TicketBookingService.model.CustomerResponse;
import com.example.TicketBookingService.service.TicketBookingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;


@RestController
@RequestMapping(Constant.TICKETBOOKING)
public class HttpControllerTicket {

    @Autowired
    TicketBookingService ticketBookingService;



    @PostMapping(Constant.INSERTCUSTOMER)
    @CrossOrigin(origins = Constant.CROSS_ORGIN)
    public CustomerResponse insertCustomer(@RequestBody Customer customer) {
        customer.setNetprice(0);
        try {
            ticketBookingService.addCustomer(customer);
            return null;
        } catch (Exception e) {
            e.printStackTrace();
            return ticketBookingService.customerResponse();
        }

    }

    @GetMapping(Constant.GET_CUSTOMER_BY_ID)
    public Customer getCustomerbyTicketNumber(@PathVariable int id) {
        try {
            return ticketBookingService.getCustomerDetailByTicketNumber(id);
        } catch (Exception e) {
            e.printStackTrace();
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage(), e);
        }
    }

    @GetMapping(Constant.GET_CUSTOMER_BY_MOBILE_NUMBER)
    public Customer getCustomerbyMobileNumber(@PathVariable String number) {
        try {
            return ticketBookingService.getCustomerDetailsByMobileNumber(number);
        } catch (Exception e) {
            e.printStackTrace();
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage(), e);
        }
    }


    @GetMapping(Constant.GET_NO_OF_TICKET)
    public Customer calculateNetTicketPrice(@PathVariable int price) {
        try {
            return ticketBookingService.calculateNetTicketPrice(price);
        } catch (Exception e) {
            e.printStackTrace();
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage(), e);

        }
    }

    @DeleteMapping(Constant.DELETE_CUSTOMER)
    public CustomerResponse deleteCustomerByTicketNumber(@PathVariable int id) {
        try {
            ticketBookingService.deleteCustomerByTicketNumber(id);
            return null;
        } catch (Exception e) {
            e.printStackTrace();
            return ticketBookingService.customerResponse();        }
    }

    @GetMapping(Constant.GET_ALL_DETAILS)
    public List<Customer> getAllDetails() {
        try {
            return ticketBookingService.displayAllCustomer();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @GetMapping(Constant.GET_CUSTOMER_BY_MOVIEID)
    public List<Customer> getCustomerDetailsByMovieId(@PathVariable int id) throws CustomerDataNotFoundException {
        try {
            return ticketBookingService.getCustomerDetailsByMovieId(id);
        } catch (Exception e) {
            e.printStackTrace();
            throw new CustomerDataNotFoundException();
        }
    }

    @PostMapping(Constant.TOBOOKINGSREVICE)
    public List<Customer> sendToMovieservice() {
        try {
            return ticketBookingService.postCustomerDetails();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @PostMapping(Constant.TOBOOKINGSREVICE_TICKETNO)
    public int ticketNosendToMovieservice(@PathVariable int id) {
        try {
            return ticketBookingService.getTotalTicketNumber(id);
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }

    }

}


