package com.example.TicketBookingService.customException;

public class CustomerDataIsInvalidException extends Exception {
    public CustomerDataIsInvalidException() {
        super("Customer is invalid");
    }
}
