package com.example.TicketBookingService.validation;

import com.example.TicketBookingService.constant.Constant;
import com.example.TicketBookingService.model.Customer;

import java.util.Objects;

public class ValidationClass {
    public static boolean customerValidation(Customer customer) {
        if (!customer.getCustomername().isEmpty() && customer.getMobilenumber().length() == Constant.NUMBER_LENGTH &&
                customer.getMovieid() > Constant.NUMBER_ZERO && customer.getNoofticket() > Constant.NUMBER_ZERO &&
                !customer.getMoviename().isEmpty()) {
            return true;
        } else
            return false;
    }

    public static boolean isNotNull(Customer customer) {
        if (!Objects.isNull(customer.getCustomername())
                && !Objects.isNull(customer.getMoviename())
                && !Objects.isNull(customer.getMobilenumber())
                && !Objects.isNull(customer.getMovieid())
                && !Objects.isNull(customer.getNetprice())&& !Objects.isNull(customer.getNoofticket())
                && !Objects.isNull(customer.getTicketid())) {
            return true;
        } else {
            return false;
        }
    }
}
