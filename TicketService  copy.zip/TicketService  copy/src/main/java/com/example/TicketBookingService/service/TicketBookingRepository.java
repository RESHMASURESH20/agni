package com.example.TicketBookingService.service;

import com.example.TicketBookingService.model.Customer;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public interface TicketBookingRepository extends JpaRepository<Customer,Integer> {
    public List<Customer>findBycustomername(String name);
    public Customer findBymobilenumber(String number);
    public List<Customer> findBymovieid(int id);
    public List<Customer> findBynoofticket(int id);
}
