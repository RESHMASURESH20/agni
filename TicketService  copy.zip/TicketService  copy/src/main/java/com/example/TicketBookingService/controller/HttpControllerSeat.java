package com.example.TicketBookingService.controller;

import com.example.TicketBookingService.constant.Constant;
import com.example.TicketBookingService.model.SeatBooked;
import com.example.TicketBookingService.service.SeatBookingService;
import com.example.TicketBookingService.service.TicketBookingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(Constant.SEAT_BOOKING)
public class HttpControllerSeat {

    @Autowired
    SeatBookingService seatBookingService;

    @Autowired
    TicketBookingService ticketBookingService;

    @GetMapping(Constant.SEAT_BOOKEDDATA)
    @CrossOrigin(origins = Constant.CROSS_ORGIN)

    public String seatBookedData(@RequestBody SeatBooked seatBooked) {
        try {
            //seatBooked.getSeat()
            seatBookingService.insertSeatBookedDetails(seatBooked);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @GetMapping(Constant.SEAT_BOOKEDGETAILS)
    @CrossOrigin(origins = Constant.CROSS_ORGIN)

    public List<SeatBooked> sendBookedData() {
        try {
            return seatBookingService.getTheBookedSeat();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
