package com.example.TicketBookingService.model;

import com.example.TicketBookingService.constant.Constant;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Entity
@Table(name = Constant.TICKET_BOOKING)
public class Customer {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int ticketid;
    private String customername;
    private int movieid;
    private String moviename;
    private int netprice;
    private int noofticket;
    private String mobilenumber;
}
