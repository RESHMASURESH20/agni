package com.example.TicketBookingService.service;

import com.example.TicketBookingService.customException.CustomerDataIsInvalidException;
import com.example.TicketBookingService.customException.CustomerDataNotFoundException;
import com.example.TicketBookingService.model.Customer;
import com.example.TicketBookingService.model.CustomerResponse;
import com.example.TicketBookingService.model.SeatBooked;
import com.fasterxml.jackson.core.JsonProcessingException;

import java.util.List;

public interface TicketBookingService {
    public Customer addCustomer(Customer customer) throws CustomerDataIsInvalidException;
    public void deleteCustomerByTicketNumber(int id)  throws CustomerDataNotFoundException;
    public List<Customer> getCustomerDetailsByName(String name) throws CustomerDataNotFoundException;
    public Customer getCustomerDetailByTicketNumber(int id);
    public Customer updateCustomerDetailsByTicketNumber(int id,Customer customer) throws CustomerDataIsInvalidException;
    public  Customer getCustomerDetailsByMobileNumber(String number) throws CustomerDataNotFoundException;
    public List<Customer> getCustomerDetailsByMovieId(int id) throws CustomerDataNotFoundException;
    public Customer calculateNetTicketPrice(int price);
    public List<Customer> displayAllCustomer();
    public List<Customer> postCustomerDetails() throws JsonProcessingException,CustomerDataNotFoundException;
    public int getTotalTicketNumber(int id) throws CustomerDataNotFoundException;


    public CustomerResponse customerResponse();
}
