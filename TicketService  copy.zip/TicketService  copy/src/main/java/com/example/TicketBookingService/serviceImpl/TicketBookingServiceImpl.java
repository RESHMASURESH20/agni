package com.example.TicketBookingService.serviceImpl;

import com.example.TicketBookingService.constant.Constant;
import com.example.TicketBookingService.customException.CustomerDataIsInvalidException;
import com.example.TicketBookingService.customException.CustomerDataNotFoundException;
import com.example.TicketBookingService.model.Customer;
import com.example.TicketBookingService.model.CustomerResponse;
import com.example.TicketBookingService.service.SeatBookingService;
import com.example.TicketBookingService.service.TicketBookingRepository;
import com.example.TicketBookingService.service.TicketBookingService;
import com.example.TicketBookingService.validation.ValidationClass;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.HttpStatus;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.server.ResponseStatusException;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;

@Service
public class TicketBookingServiceImpl implements TicketBookingService {
    @Value("${tax}")
    private float tax;

    @Value("${processingURL")
    private String processingURL;

    @Value("${price}")
    private int price;


    @Autowired
    TicketBookingRepository ticketBookingRepository;

    @Autowired
    KafkaTemplate<String, String> kafkaTemplate;
    @Autowired
    ObjectMapper objectMapper;

    @Autowired
    SeatBookingService seatBookingService;

    @Autowired
    CustomerResponse customerResponse;


    private RestTemplate restTemplate;

    public TicketBookingServiceImpl(RestTemplateBuilder restTemplateBuilder) {

        restTemplate = restTemplateBuilder.build();
    }

    private List<Customer> postDetails(List<Customer> customers) {
        List<Customer> listOfCustomers= ticketBookingRepository.findAll();
        return Arrays.asList(restTemplate.postForObject(processingURL, listOfCustomers, Customer.class));
    }

    @Override
    public Customer addCustomer(Customer customer) throws CustomerDataIsInvalidException {
        customer.setNetprice((int) ((customer.getNoofticket() * price) + (customer.getNoofticket() * price * tax)));
        if (ValidationClass.customerValidation(customer) && ValidationClass.isNotNull(customer))
            return ticketBookingRepository.save(customer);
        else
            throw new CustomerDataIsInvalidException();
    }

    @Override
    public void deleteCustomerByTicketNumber(int id) throws CustomerDataNotFoundException {

        if (!Objects.isNull(getCustomerDetailByTicketNumber(id)))
            ticketBookingRepository.deleteById(id);
        else throw new CustomerDataNotFoundException();
    }
    @Override
    public List<Customer> getCustomerDetailsByName(String name) throws CustomerDataNotFoundException {
        List<Customer> listOfCustomer = ticketBookingRepository.findBycustomername(name);
        if (!Objects.isNull(listOfCustomer))
            return listOfCustomer;
        else throw new CustomerDataNotFoundException();
    }
    @Override
    public Customer getCustomerDetailByTicketNumber(int id) throws ResponseStatusException {
        return ticketBookingRepository.findById(id).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "NOT FOUND "));
    }

    @Override
    public Customer updateCustomerDetailsByTicketNumber(int id, Customer customer) throws CustomerDataIsInvalidException {

        if (ValidationClass.isNotNull(customer) && ValidationClass.customerValidation(customer))
            return ticketBookingRepository.save(customer);
        else throw new CustomerDataIsInvalidException();
    }

    @Override
    public Customer getCustomerDetailsByMobileNumber(String number) throws CustomerDataNotFoundException {
        try {
            Customer customer = ticketBookingRepository.findBymobilenumber(number);
            return customer;
        } catch (Exception e) {
            e.printStackTrace();
            throw new CustomerDataNotFoundException();
        }
    }
    @Override
    public List<Customer> getCustomerDetailsByMovieId(int id) throws CustomerDataNotFoundException {
        try {
            List<Customer> listOfCustomer = ticketBookingRepository.findBymovieid(id);
            return listOfCustomer;
        } catch (Exception e) {
            e.printStackTrace();
            throw new CustomerDataNotFoundException();
        }

    }
    @Override
    public Customer calculateNetTicketPrice(int id) {

        Customer customer = getCustomerDetailByTicketNumber(id);
        customer.setNetprice((int) ((id * price) + (id * price * tax)));
        return customer;
    }
    @Override
    public List<Customer> displayAllCustomer() {
        try {
            return ticketBookingRepository.findAll();

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<Customer> postCustomerDetails() throws JsonProcessingException, CustomerDataNotFoundException {
        List<Customer> listOfCustomers= ticketBookingRepository.findAll();
        if (!Objects.isNull(listOfCustomers)) {
            kafkaTemplate.send(Constant.TOPIC, objectMapper.writeValueAsString(listOfCustomers));
            return listOfCustomers;
        } else throw new CustomerDataNotFoundException();
    }

    @Override
    public CustomerResponse customerResponse() {
        customerResponse.setCustomerResponse(Constant.UNABLE_TO_PROCESS);
        return customerResponse;
    }

    @Override
    public int getTotalTicketNumber(int id) throws CustomerDataNotFoundException{
        if(!Objects.isNull(getCustomerDetailsByMovieId(id))) {
            List<Customer> listOfCustomer = getCustomerDetailsByMovieId(id);
            int count = 0;
            for (Customer list : listOfCustomer) {
                count = count + list.getNoofticket();
            }
            return count;
        }else {
            return 0;
        }
    }
}
