package com.example.TicketBookingService.model;

import com.example.TicketBookingService.constant.Constant;
import lombok.*;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Table(name=Constant.SEATBOOKING)
@Entity
public class SeatBooked {
    @Id
    private int seat ;
    private boolean booked;
    private boolean selected;
}
