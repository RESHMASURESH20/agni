package com.example.TicketBookingService.constant;

public interface Constant {
    String TICKETBOOKING="/ticketBooking";
    String INSERTCUSTOMER="/insertCustomer";
    String GET_CUSTOMER_BY_ID="/getCustomer/{id}";
    String GET_CUSTOMER_BY_MOBILE_NUMBER="/getCustomer/number/{number}";
    String GET_NO_OF_TICKET="/getNoOfTicket/{id}/{price}";
    String DELETE_CUSTOMER="/deleteCustomer/{id}";
    String GET_ALL_DETAILS="/getAllDetails";
    String DRIVER="org.postgresql.Driver";
    String DB_URL="jdbc:postgresql://localhost:5432/postgres";
    String DB_USERNAME="postgres";
    String GET_CUSTOMER_BY_MOVIEID="/getCustomerByMovieId/{id}";
    int NUMBER_LENGTH=10;
    int NUMBER_ZERO=0;
    String KAFKAIPADDRESS="127.0.0.1:9092";
    String GROUP_ID="group_id";
    String TOPIC="ticket";
    String TOBOOKINGSREVICE="/toMovieService";
    String CROSS_ORGIN="http://localhost:8080";
    String SEAT_BOOKING="/seatBooking";
    String SEAT_BOOKEDDATA="/seatBookedData";
    String SEAT_BOOKEDGETAILS="/seatBookedDetails";
    String TICKET_BOOKING="ticketbooking";
    String SEATBOOKING="seatbooking";
    String USER_VERIFY="/userverify";
    String INSERT_USER="/insertUser";
    String DELETE_USER="/DeleteUser";
    String VERIFY_USER="/verifyUser";
    String USER_TABLE="userauth";
    String USER_FOUND="User Found";
    String DATA_FOUND="Data Found";
    String USER_NOT_FOUND="User Not Found";
    String DATA_NOT_FOUND="Data not found";
    String USER_INSERTED="User Inserted";
    String DATA_INSERTED="Data inserted";
    String USER_EXISTS_ALREADY="User Exists already";
String DATA_DELETED="Data deleted";
String USER_DELETED="user deleted";
String TOBOOKINGSREVICE_TICKETNO="/ticketNoToMovieService/{id}";
String UNABLE_TO_PROCESS="Unable to process";
}




