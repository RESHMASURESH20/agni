package com.example.TicketBookingService.service;

import com.example.TicketBookingService.customException.UserNotFoundException;
import com.example.TicketBookingService.model.Response;
import com.example.TicketBookingService.model.User;

public interface UserService {
    public boolean insertUser(User user);
    public boolean deleteUserDetails(User user);
    public boolean searchForUser(String  number);


    public Response userFound();
    public Response userNotFound();
    public Response userDataInserted();
    public Response userExistAlready();
    public Response  deleteUserData();
}
