package com.example.TicketBookingService.serviceImpl;

import com.example.TicketBookingService.constant.Constant;
import com.example.TicketBookingService.customException.UserNotFoundException;
import com.example.TicketBookingService.model.Response;
import com.example.TicketBookingService.model.User;
import com.example.TicketBookingService.service.UserRepository;
import com.example.TicketBookingService.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Objects;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    UserRepository userRepository;

    @Autowired
    Response response;



    @Override
    public boolean insertUser(User user) {
        if(Objects.isNull(userRepository.findByphonenumber(user.getPhonenumber()))) {
            userRepository.save(user);
            return true;
        }else
        {
            return false;
        }
    }

    @Override
    public boolean deleteUserDetails(User user) {
        try {
            if (!Objects.isNull(userRepository.findByphonenumber(user.getPhonenumber()))) {
                userRepository.deleteById(userRepository.findByphonenumber(user.getPhonenumber()).getUserid());
                return true;
            }
            throw new UserNotFoundException();
        } catch (UserNotFoundException e) {
            return false;
        }
    }


    @Override
    public boolean searchForUser(String number) {

        if (!Objects.isNull(userRepository.findByphonenumber(number))){
              return true;
        } else {

return false;        }
    }



    @Override
    public Response userFound() {
        response.setDatafound(true);
        response.setResponseStatus(Constant.USER_FOUND);
        response.setDataStatus(Constant.DATA_FOUND);
        return response;
    }

    @Override
    public Response userNotFound() {
        response.setDatafound(false);
        response.setResponseStatus(Constant.USER_NOT_FOUND);
        response.setDataStatus(Constant.DATA_NOT_FOUND);
        return response;
    }

    @Override
    public Response userDataInserted() {
        response.setDatafound(false);
        response.setResponseStatus(Constant.USER_INSERTED);
        response.setDataStatus(Constant.DATA_INSERTED);
        return response;
    }

    @Override
    public Response userExistAlready() {
        response.setDatafound(true);
        response.setResponseStatus(Constant.USER_EXISTS_ALREADY);
        response.setDataStatus(Constant.DATA_FOUND);
        return response;
    }
    @Override
    public Response  deleteUserData()
    {
        response.setDataStatus(Constant.DATA_DELETED);
        response.setDatafound(true);
        response.setResponseStatus(Constant.USER_DELETED);
        return response;
    }
}
