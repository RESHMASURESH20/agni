package com.example.TicketBookingService.service;

import com.example.TicketBookingService.model.CustomerResponse;
import com.example.TicketBookingService.model.SeatBooked;

import java.util.List;

public interface SeatBookingService {

    public void insertSeatBookedDetails(SeatBooked seatBookedData);
    public List<SeatBooked> getTheBookedSeat();
}
