package com.example.TicketBookingService.controller;
import com.example.TicketBookingService.constant.Constant;
import com.example.TicketBookingService.model.Response;
import com.example.TicketBookingService.model.User;
import com.example.TicketBookingService.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
@RestController
@RequestMapping(Constant.USER_VERIFY)
public class HttpControllerUser {

    @Autowired
    UserService userService;
    @PostMapping(Constant.INSERT_USER)
    @CrossOrigin(origins = Constant.CROSS_ORGIN)

    public Response insertUser(@RequestBody User user) {
           if(userService.insertUser(user))
           {
               return userService.userDataInserted();
           }
           else {
               return userService.userExistAlready();
           }
    }
    @PostMapping(Constant.DELETE_USER)
    @CrossOrigin(origins = Constant.CROSS_ORGIN)
    public Response deleteUser(@RequestBody User user) {
        if(userService.deleteUserDetails(user))
        {
            return userService.deleteUserData();
        }
        else
        {
            return userService.userNotFound();

        }
    }
    @PostMapping(Constant.VERIFY_USER)
    @CrossOrigin(origins = Constant.CROSS_ORGIN)
    public Response verifyUser(@RequestBody User user) {
       if(userService.searchForUser(user.getPhonenumber()))
       {
           return userService.userFound();
       }
       else {
           return userService.userNotFound();

       }
    }
}
