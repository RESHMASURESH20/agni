package com.example.TicketBookingService.customException;

public class CustomerDataNotFoundException extends Exception{
   public CustomerDataNotFoundException()
    {
        super("Customer data is not found.");
    }
}
