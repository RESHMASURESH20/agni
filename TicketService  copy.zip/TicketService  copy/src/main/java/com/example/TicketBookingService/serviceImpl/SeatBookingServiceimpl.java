package com.example.TicketBookingService.serviceImpl;
import com.example.TicketBookingService.model.CustomerResponse;
import com.example.TicketBookingService.model.SeatBooked;
import com.example.TicketBookingService.service.SeatBookingService;
import com.example.TicketBookingService.service.SeatBookingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@Service
public class SeatBookingServiceimpl  implements SeatBookingService {

    @Autowired
    SeatBookingRepository seatBookingRepository;



    @Override
    public void insertSeatBookedDetails(SeatBooked seatBookedData) {
        try {
             seatBookingRepository.save(seatBookedData);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public SeatBooked getTheSeatNumber(int id)
    {

        return  seatBookingRepository.findById(id).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND,"NOT FOUND"+id));
    }

    @Override
    public List<SeatBooked> getTheBookedSeat()
    {
        List<SeatBooked> listOfSeatbooked = seatBookingRepository.findAll();
        return listOfSeatbooked;

    }


}
