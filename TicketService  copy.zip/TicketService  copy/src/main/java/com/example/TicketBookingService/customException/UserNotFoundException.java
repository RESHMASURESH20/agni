package com.example.TicketBookingService.customException;

public class UserNotFoundException  extends Exception{
    public UserNotFoundException() {
        super("User Not Found");
    }
}
