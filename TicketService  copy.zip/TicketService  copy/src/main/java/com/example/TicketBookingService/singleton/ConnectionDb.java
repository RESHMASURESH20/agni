package com.example.TicketBookingService.singleton;

import com.example.TicketBookingService.constant.Constant;

import java.sql.DriverManager;

public class ConnectionDb {
    public static java.sql.Connection connection = null;
    private static ConnectionDb connectionDb = new ConnectionDb();

    static {
        try {
            Class.forName(Constant.DRIVER);
            connection = DriverManager
                    .getConnection(Constant.DB_URL,
                            Constant.DB_USERNAME, "");
        } catch (Exception e) {
            System.out.println("Exception in creating ConnectionDb : " + e);
        }
    }

    private ConnectionDb() {
    }

    public static ConnectionDb getInstance()
    {
        return connectionDb;
    }

    public static java.sql.Connection getConnection()
    {
        return connection;
    }

}